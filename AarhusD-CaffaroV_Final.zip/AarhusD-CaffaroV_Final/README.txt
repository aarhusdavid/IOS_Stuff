Final Project
CPSC 357 IOS Dev
Team Members: David Aarhus (2291228), Vinny Caffaro (2298196)
12/15/2020

Resources:

https://www.youtube.com/watch?v=LrCqXmHenJY (reference for the delete button)

https://stackoverflow.com/questions/43402434/how-to-edit-the-content-of-a-table-cell-in-swift-3/43402520 (reference for editing tableView content)

https://stackoverflow.com/questions/41674497/get-date-from-date-picker-to-string-in-a-variable (reference for datepicker functionality)

https://www.youtube.com/watch?v=E6Cw5WLDe-U (reference for adding todolist object with date, title, and notes)

https://www.hackingwithswift.com/forums/ios/uitableview-swipe-actions-ios13-swift-5/2256 (reference for deleting and editing tasks)

https://stackoverflow.com/questions/37967919/how-to-add-multiple-lines-in-uitableviewcell (reference for adding multiple lines to UITableViewCell)

https://stackoverflow.com/questions/31469172/show-am-pm-in-capitals-in-swift (reference for displaying date pickers hour, min, and am/pm)

https://stackoverflow.com/questions/48689631/how-to-sort-cells-in-tableview/48689705 (reference for sorting titles and dates)


