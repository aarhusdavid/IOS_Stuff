//
//  SecondTabController.swift
//  dAarhus_Project03
//
//  Created by David Aarhus on 10/20/20.
//  Copyright © 2020 David Aarhus. All rights reserved.
//

import UIKit

class SecondTabController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
